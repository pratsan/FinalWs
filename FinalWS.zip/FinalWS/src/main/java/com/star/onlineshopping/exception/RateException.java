package com.star.onlineshopping.exception;

public class RateException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public RateException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
