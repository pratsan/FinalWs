/**
 * 
 */
package com.star.onlineshopping.exception;

/**
 * @author User1
 *
 */
public class UserNotFoundException extends Exception{

	private static final long serialVersionUID = -1747502351308293745L;

	public UserNotFoundException(String message) {
		super(message);
	}

}
