package com.star.onlineshopping.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * @author Atukuri Manideepika
 * @since 2020-03-23
 *
 */
@Setter
@Getter
public class UserDto {
	private String email;
	private String password;

	

}
