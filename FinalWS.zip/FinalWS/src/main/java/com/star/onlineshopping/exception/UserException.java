package com.star.onlineshopping.exception;

public class UserException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UserException(String arg0) {
		super(arg0);
		
	}
	

}
