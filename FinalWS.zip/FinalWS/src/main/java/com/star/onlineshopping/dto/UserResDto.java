/**
 * 
 */
package com.star.onlineshopping.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * @author User1
 *
 */
@Setter
@Getter
public class UserResDto {
	
	private int statusCode;
	private String message;
	private String userName;
	

}
