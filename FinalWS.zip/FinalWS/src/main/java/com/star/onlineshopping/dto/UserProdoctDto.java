package com.star.onlineshopping.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class UserProdoctDto {

private long productId; 
private int quantity;

}
