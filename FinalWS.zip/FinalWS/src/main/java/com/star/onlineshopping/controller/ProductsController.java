package com.star.onlineshopping.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.star.onlineshopping.dto.PraductAddDto;
import com.star.onlineshopping.dto.ProductResDto;
import com.star.onlineshopping.dto.ProductsDto;
import com.star.onlineshopping.dto.RateProductDto;
import com.star.onlineshopping.dto.ResponseDto;
import com.star.onlineshopping.dto.SearchReqDto;
import com.star.onlineshopping.exception.ProductException;
import com.star.onlineshopping.exception.RateException;
import com.star.onlineshopping.exception.UserException;
import com.star.onlineshopping.exception.UserNotFoundException;
import com.star.onlineshopping.service.ProductsService;

/**
 * @author Prateek
 * @since 2020-03-23
 *
 */
@RestController
@RequestMapping("products")
public class ProductsController {
	@Autowired
	ProductsService productService;

	/**
	 * 
	 * @param email
	 * @return ResponseEntity object if product is found for particular user
	 * @throws UserException
	 * @throws ProductException
	 */
	@GetMapping("/{emailId}")
	public ResponseEntity<List<ProductsDto>> getProductByEmail(@PathVariable("emailId") String email)
			throws UserException, ProductException {
		List<ProductsDto> productList = productService.getProductByEmail(email);
		return new ResponseEntity<>(productList, HttpStatus.ACCEPTED);
	}
	
	/**author Nagajyoti
	 * @since 2020-03-26
	 * @param praductAddDto- contails the product details
	 * @return - succes or failure message along with status code
	 * @throws UserNotFoundException - if user is not present throws user not found exception
	 */
	@PostMapping()
	public ResponseEntity<ResponseDto> addProducts(@RequestBody PraductAddDto praductAddDto) throws  UserNotFoundException {
		ResponseDto responseDto = productService.addProduct(praductAddDto);
		return new ResponseEntity<>(responseDto, HttpStatus.OK);
	}
	
	
	
	/**author Nagajyoti
	 * @since 2020-03-26
	 * @param userId to get the type of user
	 * @param searchReqDto contains request param
	 * @return List<ProductResDto> based on search criteria
	 * @throws ProductException
	 * @throws UserNotFoundException
	 * @throws UserException
	 */
	@PostMapping("users/{userId}/products/productName")
	public ResponseEntity<List<ProductResDto>> getProductByProductName(@PathVariable("userId") Long userId , @RequestBody SearchReqDto searchReqDto)
			throws ProductException, UserNotFoundException,UserException {
		List<ProductResDto> productList = productService.searchProductByProdName(searchReqDto, userId);
		return new ResponseEntity<>(productList, HttpStatus.ACCEPTED);
	}
	
	/**
	 * 
	 * @param rateProductDto
	 * @return ResponseEntity object if user rated successfully
	 * @throws UserException
	 * @throws RateException
	 */
	@PostMapping("/rating")
	public ResponseEntity<ResponseDto> rateProduct(@RequestBody RateProductDto rateProductDto)
			throws UserException, RateException {
		ResponseDto responseDto = productService.rateProduct(rateProductDto);
		return new ResponseEntity<>(responseDto, HttpStatus.ACCEPTED);
	}

}
