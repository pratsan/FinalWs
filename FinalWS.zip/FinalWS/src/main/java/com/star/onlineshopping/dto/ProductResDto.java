/**
 * 
 */
package com.star.onlineshopping.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * @author User1
 *
 */

@Setter
@Getter
public class ProductResDto {
	
	private String name;

	private String description;

	private Double price;

	private String productCode;

	private String type;

	private int quantity;
	
	private float rating;

}
